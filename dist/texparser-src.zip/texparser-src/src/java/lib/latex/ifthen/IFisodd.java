/*
    Copyright (C) 2013 Nicola L.C. Talbot
    www.dickimaw-books.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/
package com.dickimawbooks.texparserlib.latex.ifthen;

import java.io.IOException;

import com.dickimawbooks.texparserlib.*;
import com.dickimawbooks.texparserlib.latex.*;

public class IFisodd extends Command
{
   public IFisodd()
   {
      this("isodd");
   }

   public IFisodd(String name)
   {
      super(name);
   }

   public Object clone()
   {
      return new IFisodd(getName());
   }

   public TeXObjectList expandonce(TeXParser parser, TeXObjectList stack)
     throws IOException
   {
      TeXObjectList list = new TeXObjectList();

      TeXObject arg = stack.popArg(parser);

      if (arg instanceof Expandable)
      {
         TeXObjectList expanded = ((Expandable)arg).expandfully(parser, stack);

         if (expanded != null)
         {
            arg = expanded;
         }
      }

      int number;

      if (arg instanceof Numerical)
      {
         number = ((Numerical)arg).number(parser);
      }
      else
      {
         String str = arg.toString(parser);

         try
         {
            number = Integer.parseInt(str);
         }
         catch (NumberFormatException e)
         {
            throw new TeXSyntaxException(e, parser, 
             TeXSyntaxException.ERROR_NUMBER_EXPECTED, str);
         }
      }

      list.add(new UserBoolean(number%2 == 1));

      return list;
   }

   public TeXObjectList expandonce(TeXParser parser)
     throws IOException
   {
      TeXObjectList list = new TeXObjectList();

      TeXObject arg = parser.popNextArg();

      if (arg instanceof Expandable)
      {
         TeXObjectList expanded = ((Expandable)arg).expandfully(parser);

         if (expanded != null)
         {
            arg = expanded;
         }
      }

      int number;

      if (arg instanceof Numerical)
      {
         number = ((Numerical)arg).number(parser);
      }
      else
      {
         String str = arg.toString(parser);

         try
         {
            number = Integer.parseInt(str);
         }
         catch (NumberFormatException e)
         {
            throw new TeXSyntaxException(e, parser, 
             TeXSyntaxException.ERROR_NUMBER_EXPECTED, str);
         }
      }

      list.add(new UserBoolean(number%2 == 1));

      return list;
   }

   public void process(TeXParser parser, TeXObjectList stack)
     throws IOException
   {
      expandonce(parser, stack).process(parser, stack);
   }

   public void process(TeXParser parser)
     throws IOException
   {
      expandonce(parser).process(parser);
   }

}
